import socket
import datetime

def load_blacklist():
    try:
        with open("blacklist.txt", "r") as f:
            return [line.strip() for line in f.readlines()]
    except FileNotFoundError:
        return []

def log_activity(message):
    with open("log.txt", "a") as log:
        log.write(str(datetime.datetime.now()) + " - " + message + "\n")

blacklist = load_blacklist()

server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server.bind(("0.0.0.0", 8080))
server.listen(5)

print("Firewall Running on port 8080...")

while True:
    client, addr = server.accept()
    client_ip = addr[0]
    print("Connection from:", client_ip)

    if client_ip in blacklist:
        print("Blocked:", client_ip)
        log_activity("Blocked IP: " + client_ip)
        client.close()
    else:
        print("Allowed:", client_ip)
        log_activity("Allowed IP: " + client_ip)
        client.send(b"Access Granted by Personal Firewall")
        client.close()
