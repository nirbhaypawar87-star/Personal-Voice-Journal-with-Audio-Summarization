Personal Firewall Project (Python)

Description:
- Blocks blacklisted IP addresses
- Logs all incoming connections
- Runs on port 8080

How to Run:
1. Install Python 3
2. Run: python firewall.py
3. Edit blacklist.txt to block specific IPs
