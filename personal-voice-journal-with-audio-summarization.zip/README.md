# 🎙️ Personal Voice Journal with Audio Summarization

## Author: Nirbhay Pawar

This project allows users to record personal voice journals, convert speech to text, and generate concise summaries using NLP techniques.

## Features
- Voice recording
- Speech-to-text transcription
- AI-based text summarization
- Organized storage

## Tech Stack
- Python
- SpeechRecognition / Whisper
- NLP Summarization

## How to Run
```bash
pip install -r requirements.txt
python app.py
```
