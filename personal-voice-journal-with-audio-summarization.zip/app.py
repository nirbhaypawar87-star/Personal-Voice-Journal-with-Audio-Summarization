print("Personal Voice Journal with Audio Summarization")
print("This is a demo entry point for the project.")