
# Personal Voice Journal - Production Ready Version

## Single Server Deployment

Frontend + Backend combined in one Express server.
Ready to deploy directly on Render / Railway / Cyclic.

## Run Locally

1. Install dependencies:
   npm install

2. Start server:
   npm start

3. Open browser:
   http://localhost:5000

## Deploy on Render

- Create New Web Service
- Connect GitHub Repo
- Build Command: npm install
- Start Command: npm start

Done.
