const express = require('express');
const cors = require('cors');
const app = express();

app.use(cors());
app.use(express.json());

app.post('/summarize', (req, res) => {
    const { text } = req.body;
    const summary = text.split(" ").slice(0, 5).join(" ") + "...";
    res.json({ summary });
});

app.listen(5000, () => console.log("Server running on port 5000"));
